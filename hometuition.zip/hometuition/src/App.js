//App.js
// import React from "react";
// import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import Home from "./Home.js";


const App = () => {
  return (
   
      
     
     <Home/>

     
  );
};

export default App;