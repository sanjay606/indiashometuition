// import React, { useState } from 'react'

import "./Nave.css";
// import CardItems from './CardItems';

import Nave from "./Nave.js";

// import ButtonPage from './ButtonPage';

const Home = () => {
 

  return (
    <div className='btn'>
    
    <Nave/>
    
  </div>
     
       
  );
}

export default Home;